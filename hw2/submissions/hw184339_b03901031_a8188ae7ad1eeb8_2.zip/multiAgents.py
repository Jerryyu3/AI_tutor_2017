# multiAgents.py
# --------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from util import manhattanDistance
from game import Directions
import random, util

from game import Agent

class ReflexAgent(Agent):
    """
      A reflex agent chooses an action at each choice point by examining
      its alternatives via a state evaluation function.

      The code below is provided as a guide.  You are welcome to change
      it in any way you see fit, so long as you don't touch our method
      headers.
    """


    def getAction(self, gameState):
        """
        You do not need to change this method, but you're welcome to.

        getAction chooses among the best options according to the evaluation function.

        Just like in the previous project, getAction takes a GameState and returns
        some Directions.X for some X in the set {North, South, West, East, Stop}
        """
        # Collect legal moves and successor states
        legalMoves = gameState.getLegalActions()

        # Choose one of the best actions
        scores = [self.evaluationFunction(gameState, action) for action in legalMoves]
        bestScore = max(scores)
        bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
        chosenIndex = random.choice(bestIndices) # Pick randomly among the best

        "Add more of your code here if you want to"

        return legalMoves[chosenIndex]

    def evaluationFunction(self, currentGameState, action):
        """
        Design a better evaluation function here.

        The evaluation function takes in the current and proposed successor
        GameStates (pacman.py) and returns a number, where higher numbers are better.

        The code below extracts some useful information from the state, like the
        remaining food (newFood) and Pacman position after moving (newPos).
        newScaredTimes holds the number of moves that each ghost will remain
        scared because of Pacman having eaten a power pellet.

        Print out these variables to see what you're getting, then combine them
        to create a masterful evaluation function.
        """
        # Useful information you can extract from a GameState (pacman.py)
        successorGameState = currentGameState.generatePacmanSuccessor(action)
        newPos = successorGameState.getPacmanPosition()
        newFood = successorGameState.getFood()
        newGhostStates = successorGameState.getGhostStates()
        newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]

        "*** YOUR CODE HERE ***"
        score = successorGameState.getScore()
        oldFood = currentGameState.getFood()
        if newPos in oldFood.asList():
            score += 100

        foodDist = []
        for foodPos in newFood.asList():
            foodDist.append(util.manhattanDistance(newPos, foodPos))
        if len(foodDist):
            nearestFoodDist = min(foodDist)
            score += (100 / nearestFoodDist)

        for ghostState in newGhostStates:
            if newPos == ghostState.getPosition():
                if ghostState.scaredTimer != 0:
                    score = float("inf")
                else:
                    score = float("inf") * (-1)

        return score

def scoreEvaluationFunction(currentGameState):
    """
      This default evaluation function just returns the score of the state.
      The score is the same one displayed in the Pacman GUI.

      This evaluation function is meant for use with adversarial search agents
      (not reflex agents).
    """
    return currentGameState.getScore()

class MultiAgentSearchAgent(Agent):
    """
      This class provides some common elements to all of your
      multi-agent searchers.  Any methods defined here will be available
      to the MinimaxPacmanAgent, AlphaBetaPacmanAgent & ExpectimaxPacmanAgent.

      You *do not* need to make any changes here, but you can if you want to
      add functionality to all your adversarial search agents.  Please do not
      remove anything, however.

      Note: this is an abstract class: one that should not be instantiated.  It's
      only partially specified, and designed to be extended.  Agent (game.py)
      is another abstract class.
    """

    def __init__(self, evalFn = 'scoreEvaluationFunction', depth = '2'):
        self.index = 0 # Pacman is always agent index 0
        self.evaluationFunction = util.lookup(evalFn, globals())
        self.depth = int(depth)

class MinimaxAgent(MultiAgentSearchAgent):
    """
      Your minimax agent (question 2)
    """

    def getAction(self, gameState):
        """
          Returns the minimax action from the current gameState using self.depth
          and self.evaluationFunction.

          Here are some method calls that might be useful when implementing minimax.

          gameState.getLegalActions(agentIndex):
            Returns a list of legal actions for an agent
            agentIndex=0 means Pacman, ghosts are >= 1

          gameState.generateSuccessor(agentIndex, action):
            Returns the successor game state after an agent takes an action

          gameState.getNumAgents():
            Returns the total number of agents in the game
        """
        "*** YOUR CODE HERE ***"
        legalMoves = gameState.getLegalActions()
        legalMoves.remove('Stop')
        numOfAgents = gameState.getNumAgents()
        scores = [self.minimax(gameState.generateSuccessor(0, action), self.depth, 1) for action in legalMoves]
        bestScore = max(scores)
        bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
        chosenIndex = bestIndices[0]
        #chosenIndex = random.choice(bestIndices)

        return legalMoves[chosenIndex]

    def minimax(self,gameState,depth,agentIndex):
        if gameState.isWin() or gameState.isLose() or depth == 0:
            return self.evaluationFunction(gameState)
        nextDepth = depth
        nextAgentIndex = agentIndex + 1
        if agentIndex == gameState.getNumAgents() - 1: # Last ghost
            nextDepth -= 1
            nextAgentIndex = 0
        leafScores = [self.minimax(gameState.generateSuccessor(agentIndex, action), nextDepth, nextAgentIndex)
                      for action in gameState.getLegalActions(agentIndex)]
        if not agentIndex: # Index for Pacman
            return max(leafScores)
        else: #Index for ghosts
            return min(leafScores)

class AlphaBetaAgent(MultiAgentSearchAgent):
    """
      Your minimax agent with alpha-beta pruning (question 3)
    """

    def getAction(self, gameState):
        """
          Returns the minimax action using self.depth and self.evaluationFunction
        """
        "*** YOUR CODE HERE ***"       
        legalMoves = gameState.getLegalActions()
        legalMoves.remove('Stop')
        numOfAgents = gameState.getNumAgents()
        alpha = float("inf") * (-1)
        beta = float("inf")
        scores = [self.alphabeta(gameState.generateSuccessor(0, action), self.depth, 1, alpha, beta) for action in legalMoves]
        bestScore = max(scores)
        #print bestScore
        bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
        chosenIndex = bestIndices[0]
        #chosenIndex = random.choice(bestIndices)

        return legalMoves[chosenIndex]
    

    def alphabeta(self, gameState, depth, agentIndex, alpha, beta):
        #print (self.alpha, self.beta)
        _alpha = alpha
        _beta = beta
        if gameState.isWin() or gameState.isLose() or depth == 0:
            return self.evaluationFunction(gameState)
        nextDepth = depth
        nextAgentIndex = agentIndex + 1
        if agentIndex == gameState.getNumAgents() - 1: # Last ghost
            nextDepth -= 1
            nextAgentIndex = 0
        legalMoves = gameState.getLegalActions(agentIndex)
        if not agentIndex: # Index for Pacman
            v = float("inf") * (-1)
            for action in legalMoves:
                v = max(v, self.alphabeta(gameState.generateSuccessor(agentIndex, action), nextDepth, nextAgentIndex, _alpha, _beta))
                if v > _beta or v == _beta:
                    return v
                _alpha = max(_alpha, v)
            return v
        else: # Index for ghosts
            v = float("inf")
            for action in legalMoves:
                v = min(v, self.alphabeta(gameState.generateSuccessor(agentIndex, action), nextDepth, nextAgentIndex, _alpha, _beta))
                if _alpha > v or _alpha == v:
                    return v
                _beta = min(_beta, v)
            return v        

class ExpectimaxAgent(MultiAgentSearchAgent):
    """
      Your expectimax agent (question 4)
    """

    def getAction(self, gameState):
        """
          Returns the expectimax action using self.depth and self.evaluationFunction

          All ghosts should be modeled as choosing uniformly at random from their
          legal moves.
        """
        "*** YOUR CODE HERE ***"
        legalMoves = gameState.getLegalActions()
        legalMoves.remove('Stop')
        numOfAgents = gameState.getNumAgents()
        scores = [self.expectimax(gameState.generateSuccessor(0, action), self.depth, 1) for action in legalMoves]
        bestScore = max(scores)
        bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
        #chosenIndex = bestIndices[0]
        chosenIndex = random.choice(bestIndices)

        return legalMoves[chosenIndex]

    def expectimax(self,gameState,depth,agentIndex):
        if gameState.isWin() or gameState.isLose() or depth == 0:
            return self.evaluationFunction(gameState)
        nextDepth = depth
        nextAgentIndex = agentIndex + 1
        if agentIndex == gameState.getNumAgents() - 1: # Last ghost
            nextDepth -= 1
            nextAgentIndex = 0
        leafScores = [self.expectimax(gameState.generateSuccessor(agentIndex, action), nextDepth, nextAgentIndex)
                      for action in gameState.getLegalActions(agentIndex)]
        if not agentIndex: # Index for Pacman
            return max(leafScores)
        else: #Index for ghosts
            return float(sum(leafScores)) / float(len(leafScores))

def betterEvaluationFunction(currentGameState):
    """
      Your extreme ghost-hunting, pellet-nabbing, food-gobbling, unstoppable
      evaluation function (question 5).

      DESCRIPTION: <write something here so we know what you did>
          Attributes of:
              (a) distance to the nearest capsule
              (b) number of remaining food
              (c) distance to the nearest food
              (d) average distance to all of the remaining food
              (e) distance to each ghost and (f) the scared times related
          are calculated with weighted coefficient added on the variable "score"
          The main goal is to eat all the food, while aiming at getting higher scores,
          if capsules are available and near enough, Pacman will be guided to take out
          ghosts to achieve better results.
    """
    "*** YOUR CODE HERE ***"
    score = 0
    pacmanPos = currentGameState.getPacmanPosition()
    foodPos = currentGameState.getFood().asList()
    foodDist = [util.manhattanDistance(pacmanPos, xy2) for xy2 in foodPos]
    capsulePos = currentGameState.getCapsules()
    capsuleDist = [util.manhattanDistance(pacmanPos, xy2) for xy2 in capsulePos]
    if not len(foodPos): # no more food
        score += 999999
        return score
    if len(capsuleDist):
        score += 16 / float(min(capsuleDist))
    score += 8 / float(len(foodPos))
    score += 128 / float(min(foodDist))
    score += 32 / (float(sum(foodDist)) / float(len(foodDist)))

    ghostPos = currentGameState.getGhostPositions()
    ghostStates = currentGameState.getGhostStates()
    scaredTimes = [state.scaredTimer for state in ghostStates]
    for idx in range(len(ghostPos)):
        d = util.manhattanDistance(pacmanPos, ghostPos[idx])
        if d < 3:
            if scaredTimes[idx] > d + 2.5:
                score += scaredTimes[idx] / 2
        if d < 2:
            score -= 10000
    score += 10 * currentGameState.getScore()
    return score

# Abbreviation
better = betterEvaluationFunction