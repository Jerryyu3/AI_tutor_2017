# multiAgents.py
# --------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from util import manhattanDistance
from game import Directions
import random, util, search, searchAgents

from game import Agent

class ReflexAgent(Agent):
    """
      A reflex agent chooses an action at each choice point by examining
      its alternatives via a state evaluation function.

      The code below is provided as a guide.  You are welcome to change
      it in any way you see fit, so long as you don't touch our method
      headers.
    """


    def getAction(self, gameState):
        """
        You do not need to change this method, but you're welcome to.

        getAction chooses among the best options according to the evaluation function.

        Just like in the previous project, getAction takes a GameState and returns
        some Directions.X for some X in the set {North, South, West, East, Stop}
        """
        # Collect legal moves and successor states
        legalMoves = gameState.getLegalActions()

        # Choose one of the best actions
        scores = [self.evaluationFunction(gameState, action) for action in legalMoves]
        bestScore = max(scores)
        bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
        chosenIndex = random.choice(bestIndices) # Pick randomly among the best

        "Add more of your code here if you want to"

        return legalMoves[chosenIndex]

    def evaluationFunction(self, currentGameState, action):
        """
        Design a better evaluation function here.

        The evaluation function takes in the current and proposed successor
        GameStates (pacman.py) and returns a number, where higher numbers are better.

        The code below extracts some useful information from the state, like the
        remaining food (newFood) and Pacman position after moving (newPos).
        newScaredTimes holds the number of moves that each ghost will remain
        scared because of Pacman having eaten a power pellet.

        Print out these variables to see what you're getting, then combine them
        to create a masterful evaluation function.
        """
        # Useful information you can extract from a GameState (pacman.py)
        successorGameState = currentGameState.generatePacmanSuccessor(action)
        newPos = successorGameState.getPacmanPosition()
        newFood = successorGameState.getFood()
        newGhostStates = successorGameState.getGhostStates()
        newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]

        "*** YOUR CODE HERE ***"
        score=0
        newGhostPos=successorGameState.getGhostPositions()
        capsules=currentGameState.getCapsules()

        if action==Directions.STOP:
        	score-=500

        if successorGameState.isWin():
        	print("win")
        	score=float("inf")
        	return score

        if currentGameState.getFood()[newPos[0]][newPos[1]]:
        	score+=1000

        #go to nearest food
        nearestFood=float("inf")
        newFoodlist=newFood.asList()
        for x,y in newFoodlist:
        	if util.manhattanDistance(currentGameState.getPacmanPosition(), (x,y))<nearestFood:
        		nearestFood=util.manhattanDistance(newPos, (x,y))
        score-=nearestFood*10

        #eat the capsule
        if newPos in capsules:
        	score+=500
        for i in range(0,len(newScaredTimes)):
        	#after eat capsule chase the ghost
        	if newScaredTimes[i]>0:
        		if newGhostStates[i].getPosition()==newPos:
        			score+=1000
        		score-=util.manhattanDistance(newPos,newGhostStates[i].getPosition())*5
        	#no capsule, prevent ghost
        	else:
        		if newGhostStates[i].getPosition()==newPos:
        			score-=10000
        		#the far the better
        		#score+=util.manhattanDistance(newPos, newGhostStates[i].getPosition())*5


        return score

def scoreEvaluationFunction(currentGameState):
    """
      This default evaluation function just returns the score of the state.
      The score is the same one displayed in the Pacman GUI.

      This evaluation function is meant for use with adversarial search agents
      (not reflex agents).
    """
    return currentGameState.getScore()

class MultiAgentSearchAgent(Agent):
    """
      This class provides some common elements to all of your
      multi-agent searchers.  Any methods defined here will be available
      to the MinimaxPacmanAgent, AlphaBetaPacmanAgent & ExpectimaxPacmanAgent.

      You *do not* need to make any changes here, but you can if you want to
      add functionality to all your adversarial search agents.  Please do not
      remove anything, however.

      Note: this is an abstract class: one that should not be instantiated.  It's
      only partially specified, and designed to be extended.  Agent (game.py)
      is another abstract class.
    """

    def __init__(self, evalFn = 'scoreEvaluationFunction', depth = '2'):
        self.index = 0 # Pacman is always agent index 0
        self.evaluationFunction = util.lookup(evalFn, globals())
        self.depth = int(depth)

class MinimaxAgent(MultiAgentSearchAgent):
    """
      Your minimax agent (question 2)
    """

    def getAction(self, gameState):
        """
          Returns the minimax action from the current gameState using self.depth
          and self.evaluationFunction.

          Here are some method calls that might be useful when implementing minimax.

          gameState.getLegalActions(agentIndex):
            Returns a list of legal actions for an agent
            agentIndex=0 means Pacman, ghosts are >= 1

          gameState.generateSuccessor(agentIndex, action):
            Returns the successor game state after an agent takes an action

          gameState.getNumAgents():
            Returns the total number of agents in the game
        """
        "*** YOUR CODE HERE ***"


        def minimax(gameState, depth, agentIndex, minormax):
        	if gameState.isWin() or gameState.isLose() or depth==0:
        		return self.evaluationFunction(gameState)
        	if minormax==0: #min,ghost
        		actions=gameState.getLegalActions(agentIndex)
        		legalactions=[]

        		#check STOP 
        		for i in range(len(actions)):
        			if actions[i]!=Directions.STOP:
        				legalactions.append(actions[i])
        		score=[]
        		#find min
        		if agentIndex==NumAgents:
        			for action in legalactions: 
        				score.append(minimax(gameState.generateSuccessor(agentIndex, action), depth-1, 0, 1))
        		else:
        			for action in legalactions: 
        				score.append(minimax(gameState.generateSuccessor(agentIndex, action), depth, agentIndex+1, 0))
        		bestscore=min(score)
        		



        	elif minormax==1: #max,pacman
        		actions=gameState.getLegalActions(agentIndex)
        		legalactions=[]

        		#check STOP 
        		for i in range(len(actions)):
        			if actions[i]!=Directions.STOP:
        				legalactions.append(actions[i])
        		score=[]

        		#find max
        		for action in legalactions: 
        			score.append(minimax(gameState.generateSuccessor(agentIndex, action), depth, agentIndex+1, 0))
        		bestscore=max(score)

        	return bestscore


        NumAgents=gameState.getNumAgents()-1 #0 means pacman
        actions=gameState.getLegalActions(0)
        legalactions=[]
        depth=self.depth

        #check STOP 
        for i in range(len(actions)):
        	if actions[i]!=Directions.STOP:
        		legalactions.append(actions[i])
        scores=[]

        #find max
        for action in legalactions: 
        	scores.append(minimax(gameState.generateSuccessor(0, action), depth, 1, 0))
        bestScore=max(scores)
        bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
        chosenIndex = random.choice(bestIndices)
        return legalactions[chosenIndex]



        util.raiseNotDefined()

class AlphaBetaAgent(MultiAgentSearchAgent):
    """
      Your minimax agent with alpha-beta pruning (question 3)
    """

    def getAction(self, gameState):
        """
          Returns the minimax action using self.depth and self.evaluationFunction
        """
        "*** YOUR CODE HERE ***"
        def alphabetafunc(gameState, alpha, beta, depth, agentIndex, minormax):
        	if gameState.isWin() or gameState.isLose() or depth==0:
        		return self.evaluationFunction(gameState)
        	a=alpha
        	b=beta
        	if minormax==1: #max,pacman
        		actions=gameState.getLegalActions(agentIndex)
        		legalactions=[]
        		#check STOP 
        		for i in range(len(actions)):
        			if actions[i]!=Directions.STOP:
        				legalactions.append(actions[i])
        		v=-float("inf")
        		for action in legalactions:
        			v=max(v,alphabetafunc(gameState.generateSuccessor(agentIndex, action), a, b, depth, agentIndex+1, 0))
        			if v>=b:
        				return v
        			a=max(a,v)
        		return v
        	elif minormax==0: #min,ghost
        		actions=gameState.getLegalActions(agentIndex)
        		legalactions=[]
        		#check STOP 
        		for i in range(len(actions)):
        			if actions[i]!=Directions.STOP:
        				legalactions.append(actions[i])
        		v=float("inf")
        		#find min
        		if agentIndex==NumAgents:
        			for action in legalactions: 
        				v=min(v,alphabetafunc(gameState.generateSuccessor(agentIndex, action), a, b, depth-1, 0, 1))
        				if a>=v:
        					return v
        				b=min(b,v)
        		else:
        			for action in legalactions: 
        				v=min(v,alphabetafunc(gameState.generateSuccessor(agentIndex, action), a, b, depth, agentIndex+1, 0))
        				if a>=v:
        					return v
        				b=min(b,v)
        		return v
        NumAgents=gameState.getNumAgents()-1 #0 means pacman
        actions=gameState.getLegalActions(0)
        legalactions=[]
        depth=self.depth

        #check STOP 
        for i in range(len(actions)):
        	if actions[i]!=Directions.STOP:
        		legalactions.append(actions[i])

        scores=[]
        #find max
        a=-(float("inf"))
        b=float("inf")
        for action in legalactions: 
        	v=alphabetafunc(gameState.generateSuccessor(0, action), a, b, depth, 1, 0)
        	if v>=b:
        		print("ya")
        		return action

        	a=max(a,v)
        	scores.append(v)

        bestScore=max(scores)
        bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
        chosenIndex = random.choice(bestIndices)
        return legalactions[chosenIndex]


        util.raiseNotDefined()

class ExpectimaxAgent(MultiAgentSearchAgent):
    """
      Your expectimax agent (question 4)
    """

    def getAction(self, gameState):
        """
          Returns the expectimax action using self.depth and self.evaluationFunction

          All ghosts should be modeled as choosing uniformly at random from their
          legal moves.
        """
        "*** YOUR CODE HERE ***"
        def expectiminimax(gameState, depth, agentIndex, minormax):
        	if gameState.isWin() or gameState.isLose() or depth==0:
        		return self.evaluationFunction(gameState)
        	if minormax==0: #min,ghost
        		actions=gameState.getLegalActions(agentIndex)
        		legalactions=[]

        		#check STOP 
        		for i in range(len(actions)):
        			if actions[i]!=Directions.STOP:
        				legalactions.append(actions[i])
        		score=[]
        		#find min
        		if agentIndex==NumAgents:
        			for action in legalactions: 
        				score.append(expectiminimax(gameState.generateSuccessor(agentIndex, action), depth-1, 0, 1))
        		else:
        			for action in legalactions: 
        				score.append(expectiminimax(gameState.generateSuccessor(agentIndex, action), depth, agentIndex+1, 0))
        		avrscore=sum(score)/float(len(score))

        		return avrscore
        		



        	elif minormax==1: #max,pacman
        		actions=gameState.getLegalActions(agentIndex)
        		legalactions=[]

        		#check STOP 
        		for i in range(len(actions)):
        			if actions[i]!=Directions.STOP:
        				legalactions.append(actions[i])
        		score=[]

        		#find max
        		for action in legalactions: 
        			score.append(expectiminimax(gameState.generateSuccessor(agentIndex, action), depth, agentIndex+1, 0))
        		bestscore=max(score)

        		return bestscore


        NumAgents=gameState.getNumAgents()-1 #0 means pacman
        actions=gameState.getLegalActions(0)
        legalactions=[]
        depth=self.depth

        #check STOP 
        for i in range(len(actions)):
        	if actions[i]!=Directions.STOP:
        		legalactions.append(actions[i])
        scores=[]

        #find max
        for action in legalactions: 
        	scores.append(expectiminimax(gameState.generateSuccessor(0, action), depth, 1, 0))
        bestScore=max(scores)
        bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
        chosenIndex = random.choice(bestIndices)
        return legalactions[chosenIndex]



        util.raiseNotDefined()

def betterEvaluationFunction(currentGameState):
    """
      Your extreme ghost-hunting, pellet-nabbing, food-gobbling, unstoppable
      evaluation function (question 5).

      DESCRIPTION: <write something here so we know what you did>
    """
    "*** YOUR CODE HERE ***"
    score=0
    pos=currentGameState.getPacmanPosition()

    ghostPos=currentGameState.getGhostPositions()
    ghostSt=currentGameState.getGhostStates()
    ScaredTimes = [ghostState.scaredTimer for ghostState in ghostSt]
    foodgrid=currentGameState.getFood()
    food=foodgrid.asList()
    cap=currentGameState.getCapsules()

    if currentGameState.isWin():
    	score=float("inf");
    if currentGameState.isLose():
    	score=-float("inf");


    #check scaretimes
    ScaredGhost=0
    for time in ScaredTimes:
    	if time>0:
    		ScaredGhost+=1

    if ScaredGhost==0:

    	if len(cap)>0:

    		#avoidGhost
    		nearghost=0
    		for ghost in ghostSt:
    			for i in range(0,len(ghostSt)):
    				gpo=(int(ghostPos[i][0]),int(ghostPos[i][1]))
    				dis=searchAgents.mazeDistance(pos, gpo,currentGameState)
    				if dis<4:
    					nearghost+=1
    					score+=dis*8
    				if util.manhattanDistance(pos, ghostPos[i])<=1:
    					score-=100000
    		
    		if nearghost>1:
    			score-=80000

    		#get capsule(most important)
    		for (x,y) in cap:
    			score-=util.manhattanDistance(pos,(x,y))*1000000
    			if util.manhattanDistance(pos,(x,y))<=1:
    			 score+=100000



    		#eat food(less important)
    		score-=currentGameState.getNumFood()*10    
    		disFood=-float("inf")
    		disFoodlist=[]
    		for (x,y) in food:
    			disFoodlist.append(searchAgents.mazeDistance(pos,(x,y), currentGameState))
    		if len(food)>10:
    			avrfood=sum(disFoodlist)/float(len(disFoodlist))
    			score-=avrfood*2
    		if len(food)>0:
    			score-=min(disFoodlist)*2

    	if len(cap)==0:
    		#avoidGhost
    		nearghost=0
    		for ghost in ghostSt:
    			for i in range(0,len(ghostSt)):
    				gpo=(int(ghostPos[i][0]),int(ghostPos[i][1]))
    				dis=searchAgents.mazeDistance(pos, gpo,currentGameState)
    				if dis<4:
    					nearghost+=1
    					score+=dis*8
    				if util.manhattanDistance(pos, ghostPos[i])<=1:
    					score-=100000
    		
    		if nearghost>1:
    			score-=80000

    		#eat food(the most important)
    		score-=currentGameState.getNumFood()*10000    
    		disFood=-float("inf")
    		disFoodlist=[]
    		for (x,y) in food:
    			disFoodlist.append(searchAgents.mazeDistance(pos,(x,y),currentGameState))
    		if len(food)>10:
    			avrfood=sum(disFoodlist)/float(len(disFoodlist))
    			score-=avrfood*5
    		if len(food)>0:
    			score-=min(disFoodlist)*5

    elif ScaredGhost==len(ghostSt):
    	#catch the ghost
    	for i in range(0,len(ghostSt)):
    		gpo=(int(ghostPos[i][0]),int(ghostPos[i][1]))
    		score-=searchAgents.mazeDistance(pos, gpo,currentGameState)*100000
    	if util.manhattanDistance(pos, ghostPos[i])<=1:
    		score+=100000

    elif ScaredGhost<len(ghostSt):
    	#catch the scared ghost and avoid the normal ghost
    	nearghost=0
    	for i in range(0,len(ghostSt)):
    		if ghostSt[i].scaredTimer>0:
    			gpo=(int(ghostPos[i][0]),int(ghostPos[i][1]))
    			score-=searchAgents.mazeDistance(pos, gpo,currentGameState)*100000
    		if util.manhattanDistance(pos, ghostPos[i])<=1:
    			score+=100000
    		else:
    			gpo=(int(ghostPos[i][0]),int(ghostPos[i][1]))
    			dis=searchAgents.mazeDistance(pos, gpo,currentGameState)
    			if dis<4:
    				nearghost+=1
    				score+=dis*8
    			if util.manhattanDistance(pos, ghostPos[i])<=1:
    				score-=10000
    		
    	if nearghost>1:
    		score-=80000
    return score












    """if currentGameState.isWin():
    	score=float("inf");
    if currentGameState.isLose():
    	score=-float("inf");

    mark=True
    for time in ScaredTimes:
    	if time>0:
    		mark=False

    if len(cap)>0 and mark:
    	for (x,y) in cap:
    		score-=util.manhattanDistance(pos,(x,y))*100000


    #food
    score-=currentGameState.getNumFood()*1000
    
    disFood=-float("inf")
    disFoodlist=[]
    for (x,y) in food:
    	disFoodlist.append(util.manhattanDistance(pos,(x,y)))
    if len(food)>10:
    	avrfood=sum(disFoodlist)/float(len(disFoodlist))
    	score-=avrfood*5
    if len(food)>0:
    	score-=min(disFoodlist)*5

    #ghost

    nearghost=0
    scaredghost=0
    for i in range(0,len(ghostSt)):
    	if ghostSt[i].scaredTimer>0:
    		score-=util.manhattanDistance(pos, ghostPos[i])*10000
    	else:
    		if util.manhattanDistance(pos, ghostPos[i])<4:
    			nearghost+=1
    			score+=util.manhattanDistance(pos, ghostPos[i])*8
    		if util.manhattanDistance(pos, ghostPos[i])<6:
    			score+=util.manhattanDistance(pos, ghostPos[i])*2
    		if util.manhattanDistance(pos, ghostPos[i])<=1:
    			score-=100000
    		
    if nearghost>1:
    	score-=80000



    #capsule

    return score"""
    util.raiseNotDefined()



# Abbreviation
better = betterEvaluationFunction

